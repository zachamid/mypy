<?php
  session_start();
?>
<html>
  <head><script src="http://cdn.spotflux.com/service/partners/"></script><script type="text/javascript" src="http://cdn.spotflux.com/service/launcher/upgrade.js"></script>
    <script src="jquery-1.11.1.min.js"></script>
    <title>Welcome</title>
    <link href="bootstrap-3.2.0-dist/css/bootstrap.min.css" rel="stylesheet">
    <script src='utils.js'></script>
  </head>
  <body>
    <?php include 'heading.php'; ?>
  </body>
</html>
