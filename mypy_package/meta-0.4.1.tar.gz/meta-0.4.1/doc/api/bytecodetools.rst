:mod:`meta.bytecodetools` - operate on python byte-code
==========================================================

.. automodule:: meta.bytecodetools
    :members:
    :undoc-members:
    :member-order: bysource


.. autoclass:: meta.bytecodetools.Instruction

.. autoclass:: meta.bytecodetools.disassembler

.. autoclass:: meta.bytecodetools.ByteCodeConsumer

.. autoclass:: meta.bytecodetools.StackedByteCodeConsumer